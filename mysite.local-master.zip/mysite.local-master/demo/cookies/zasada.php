﻿<?php
	setcookie("test", "hello");
?>
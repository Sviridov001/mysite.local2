<?php
	setcookie("userName", 'John');
?>